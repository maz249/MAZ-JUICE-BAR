function showPage(id){
  document.querySelectorAll('.page').forEach(p=>p.style.display='none');
  document.getElementById(id).style.display='block';
}

// إظهار التصنيفات كبداية
document.addEventListener('DOMContentLoaded', ()=>{
  showPage('categories');
});
